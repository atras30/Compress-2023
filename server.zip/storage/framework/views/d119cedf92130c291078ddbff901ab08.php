

<?php $__env->startSection('styles'); ?>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <iframe src="<?php echo e(asset('/pendaftar/'.$User->pathfilehasilkarya)); ?>" style="width: 100%; height: 100vh;" frameborder="0"></iframe>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nabil\Commpress-2023\Compress-2023\resources\views/admin/viewmore-userPDF.blade.php ENDPATH**/ ?>