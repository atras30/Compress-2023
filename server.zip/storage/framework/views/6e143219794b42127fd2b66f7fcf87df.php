<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
        <p><?php echo e($mailData['body']); ?></p>
        
        <script src="" async defer></script>
    </body>
</html><?php /**PATH C:\Nabil\Commpress-2023\Compress-2023\resources\views/sendEmail.blade.php ENDPATH**/ ?>