<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contents"); ?>
<div class="container">
  <div class="vh-100 d-flex justify-content-center align-items-center">
    <div class="content text-center">
        
        <a href="<?php echo e(route('divisi')); ?>" class="custom-btn btn-2">Go To Divisi</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.user.master_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nabil\Commpress-2023\Compress-2023\resources\views/homeRegis.blade.php ENDPATH**/ ?>