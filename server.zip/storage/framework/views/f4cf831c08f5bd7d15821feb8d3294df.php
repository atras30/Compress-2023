<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contents"); ?>
<div class="container center-div">
    <img class="logo-tv" src="<?php echo e(asset('images/commpress2022.svg')); ?>"/>
  <h2 class="text-center mt-4">Welcome, Admin!</h2>
  <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
  <?php endif; ?>
  <form action="/admin/login" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <input type="email" class="form-control" id="email" name="email" placeholder="Username/Email">
    </div>
    <div class="mb-3 ">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
        <div class="text-start justify-content-start mt-2 ms-2">
          <input type="checkbox" id="showPassword"> Show Password
        </div>
    </div>
    <button type="submit" class="btn btn-primary btn-submit">Login</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js" ></script>
<script>
  $(document).ready(function(){
    $('#showPassword').on('change', function(){
      $('#password').attr('type',$('#showPassword').prop('checked')==true?"text":"password"); 
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.admin.master_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nabil\Commpress-2023\Compress-2023\resources\views/admin/login.blade.php ENDPATH**/ ?>