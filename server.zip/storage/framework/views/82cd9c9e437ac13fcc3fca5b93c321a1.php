<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
        <h1><?php echo e($mailData['title']); ?></h1>
        <p><?php echo e($mailData['body']); ?></p>
        
        <script src="" async defer></script>
    </body>
</html><?php /**PATH C:\Nabil\Commpress-2023\Compress-2023\resources\views/admin/sendEmail.blade.php ENDPATH**/ ?>