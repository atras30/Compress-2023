<?php $__env->startSection('styles'); ?>
<style>
  .error-text{
    font-size: 12px;
    color:red;
  }
  
</style>
<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet"/>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("contents"); ?>
<div class="main">
  <div class="container py-5">
    <div class="container-form">
      <h1>PENDAFTARAN PANITIA COMMPRESS 2023</h1>
      <p>Data ini hanya akan digunakan untuk tim COMMPRESS 2022 menghubungi kalian. Diisi dengan teliti, ya! Tidak perlu khawatir, COMMPRESS 2023 akan menjaga kerahasiaan data kamu!</p>
      <form action="<?php echo e(route('recruitment.validate')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-2 ">
          <label for="fullname">Nama Lengkap</label>
          <input type="text" name="fullname" class="form-control" value=<?php echo e(@old('fullname')); ?>>
          <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="nickname">Nama Panggilan</label>
          <input type="text" name="nickname" class="form-control" value=<?php echo e(@old('nickname')); ?>>
          <?php $__errorArgs = ['nickname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="angkatan">Angkatan</label>
          <select class="form-select" name="angkatan" placeholder="Angkatan">
            <option <?php if(old('angkatan') === "2020"): ?> selected <?php endif; ?> value="2020">2020</option>
            <option <?php if(old('angkatan') === "2021"): ?> selected <?php endif; ?> value="2021">2021</option>
            <option <?php if(old('angkatan') === "2022"): ?> selected <?php endif; ?> value="2022">2022</option>
          </select>
          <?php $__errorArgs = ['angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="nim">NIM</label>
          <input type="text" name="nim" placeholder="ex: 00000012345" class="form-control" value=<?php echo e(@old('nim')); ?>>
          <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="prodi">Program Studi</label>
          <select class="form-select" name="prodi" placeholder="Jurusan">
            <option <?php if(old('prodi') === 'Informatika'): ?> selected <?php endif; ?> value="Informatika">Informatika</option>
            <option <?php if(old('prodi') === "Teknik Komputer"): ?> selected <?php endif; ?> value="Teknik Komputer">Teknik Komputer</option>
            <option <?php if(old('prodi') === "Teknik Elektro"): ?> selected <?php endif; ?> value="Teknik Elektro">Teknik Elektro</option>
            <option <?php if(old('prodi') === "Teknik Fisika"): ?> selected <?php endif; ?> value="Teknik Fisika">Teknik Fisika</option>
            <option <?php if(old('prodi') === "Sistem Informasi"): ?> selected <?php endif; ?> value="Sistem Informasi">Sistem Informasi</option>
            <option <?php if(old('prodi') === "Akuntansi"): ?> selected <?php endif; ?> value="Akuntansi">Akuntansi</option>
            <option <?php if(old('prodi') === "Manajemen"): ?> selected <?php endif; ?> value="Manajemen">Manajemen</option>
            <option <?php if(old('prodi') === "Perhotelan"): ?> selected <?php endif; ?> value="Perhotelan">Perhotelan</option>
            <option <?php if(old('prodi') === "Komunikasi Strategis"): ?> selected <?php endif; ?> value="Komunikasi Strategis">Komunikasi Strategis</option>
            <option <?php if(old('prodi') === "Jurnalistik"): ?> selected <?php endif; ?> value="Jurnalistik">Jurnalistik</option>
            <option <?php if(old('prodi') === "Desain Komunikasi Visual"): ?> selected <?php endif; ?> value="Desain Komunikasi Visual">Desain Komunikasi Visual</option>
            <option <?php if(old('prodi') === "Arsitektur"): ?> selected <?php endif; ?> value="Arsitektur">Arsitektur</option>
            <option <?php if(old('prodi') === "Film & Animasi"): ?> selected <?php endif; ?> value="Film & Animasi">Film & Animasi</option>
          </select>
          <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="tanggallahir">Tanggal lahir</label>
          <input type="date" name="tanggallahir" class="form-control" value=<?php echo e(@old('tanggallahir')); ?>>
          <?php $__errorArgs = ['tanggallahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="email">Email Student</label>
          <input type="email" name="email" class="form-control" value=<?php echo e(@old('email')); ?>>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="noHp">Nomor HP Aktif</label>
          <input type="text" name="noHp" class="form-control" value=<?php echo e(@old('noHp')); ?>>
          <?php $__errorArgs = ['noHp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="idLine">ID Line</label><br>
          <small>(Pastikan bahwa ejaannya benar dan telah menonaktifkan fitur 'FILTER MESSAGE')</small>
          <input type="text" name="idLine" class="form-control" value=<?php echo e(@old('idLine')); ?>>
          <?php $__errorArgs = ['idLine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="instagram">Instagram</label>
          <input type="text" name="instagram" class="form-control" value=<?php echo e(@old('instagram')); ?>>
          <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="divisi1">TIM (pilihan 1)</label>
          <select class="form-select" name="divisi1">
            <option <?php if(old('divisi1') === 'Acara'): ?> selected <?php endif; ?> value="Acara">Acara</option>
            <option <?php if(old('divisi1') === "Lomba"): ?> selected <?php endif; ?> value="Lomba">Lomba</option>
            <option <?php if(old('divisi1') === "Fresh Money"): ?> selected <?php endif; ?> value="Fresh Money">Fresh Money</option>
            <option <?php if(old('divisi1') === "Sponsor"): ?> selected <?php endif; ?> value="Sponsor">Sponsor</option>
            <option <?php if(old('divisi1') === "Publikasi"): ?> selected <?php endif; ?> value="Publikasi">Publikasi</option>
            <option <?php if(old('divisi1') === "Visual"): ?> selected <?php endif; ?> value="Visual">Visual</option>
            <option <?php if(old('divisi1') === "Perlengkapan"): ?> selected <?php endif; ?> value="Perlengkapan">Perlengkapan</option>
            <option <?php if(old('divisi1') === "Media Relation"): ?> selected <?php endif; ?> value="Media Relation">Media Relation</option>
            <option <?php if(old('divisi1') === "Dokumentasi Foto"): ?> selected <?php endif; ?> value="Dokumentasi Foto">Dokumentasi Foto</option>
            <option <?php if(old('divisi1') === "Dokumentasi Video"): ?> selected <?php endif; ?> value="Dokumentasi Video">Dokumentasi Video</option>
            <option <?php if(old('divisi1') === "Editor Foto"): ?> selected <?php endif; ?> value="Editor Foto">Editor Foto</option>
            <option <?php if(old('divisi1') === "Editor Video"): ?> selected <?php endif; ?> value="Editor Video">Editor Video</option>
          </select>
          <?php $__errorArgs = ['divisi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="alasandiv1">Alasan memilih TIM pertama</label>
          <textarea type="text" name="alasandiv1" class="form-control" rows="3"><?php echo e(old('alasandiv1')); ?></textarea>
          <?php $__errorArgs = ['alasandiv1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="divisi2">TIM (pilihan 2)</label>
          <select class="form-select" name="divisi2">
            <option <?php if(old('divisi2') === 'Acara'): ?> selected <?php endif; ?> value="Acara">Acara</option>
            <option <?php if(old('divisi2') === "Lomba"): ?> selected <?php endif; ?> value="Lomba">Lomba</option>
            <option <?php if(old('divisi2') === "Fresh Money"): ?> selected <?php endif; ?> value="Fresh Money">Fresh Money</option>
            <option <?php if(old('divisi2') === "Sponsor"): ?> selected <?php endif; ?> value="Sponsor">Sponsor</option>
            <option <?php if(old('divisi2') === "Publikasi"): ?> selected <?php endif; ?> value="Publikasi">Publikasi</option>
            <option <?php if(old('divisi2') === "Visual"): ?> selected <?php endif; ?> value="Visual">Visual</option>
            <option <?php if(old('divisi2') === "Perlengkapan"): ?> selected <?php endif; ?> value="Perlengkapan">Perlengkapan</option>
            <option <?php if(old('divisi2') === "Media Relation"): ?> selected <?php endif; ?> value="Media Relation">Media Relation</option>
            <option <?php if(old('divisi2') === "Dokumentasi Foto"): ?> selected <?php endif; ?> value="Dokumentasi Foto">Dokumentasi Foto</option>
            <option <?php if(old('divisi2') === "Dokumentasi Video"): ?> selected <?php endif; ?> value="Dokumentasi Video">Dokumentasi Video</option>
            <option <?php if(old('divisi2') === "Editor Foto"): ?> selected <?php endif; ?> value="Editor Foto">Editor Foto</option>
            <option <?php if(old('divisi2') === "Editor Video"): ?> selected <?php endif; ?> value="Editor Video">Editor Video</option>
          </select>
          <?php $__errorArgs = ['divisi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="alasandiv2">Alasan memilih TIM kedua</label>
          <textarea type="text" name="alasandiv2" class="form-control" rows="3"><?php echo e(old('alasandiv2')); ?></textarea>
          <?php $__errorArgs = ['alasandiv2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="pengalaman">Apa saja pengalaman organisasi kamu?</label>
          <textarea type="text" name="pengalaman" class="form-control" rows="3"><?php echo e(old('pengalaman')); ?></textarea>
          <?php $__errorArgs = ['pengalaman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="kesibukan">Apa saja kesibukan kamu?</label><br>
          <small>(rentang April hingga September 2023 ini)</small>
          <textarea type="text" name="kesibukan" class="form-control" rows="3"><?php echo e(old('kesibukan')); ?></textarea>
          <?php $__errorArgs = ['kesibukan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="alasan_masuk_commpress">Mengapa kamu mendaftar di COMMPRESS 2023?</label>
          <textarea type="text" name="alasan_masuk_commpress" class="form-control" rows="3"><?php echo e(old('alasan_masuk_commpress')); ?></textarea>
          <?php $__errorArgs = ['alasan-masuk-commpress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 ">
          <label for="portofolio">Bagi kamu yang memilih Tim Visual & Dokumentasi (Foto, Video, dan Editor), silakan mengirimkan tautan portofolio kamu yaa!</label><br>
          <small>Tautan berupa link drive</small><br>
          <small>Bagi kamu yang mendaftar di luar kedua divisi di atas, harap mengisi dengan "-".</small>
          <div class="terms p-3 my-4">
            <p>KETENTUAN PORTOFOLIO</p>
            <p>1. TIM VISUAL: </p>
            <ul>
              <li>3 desain bertemakan "pop art" atau "komik</li>
              <li>nilai tambah untuk kamu yang bisa membuat doodle art</li>
            </ul>
            <p>2. TIM DOKUMENTASI:</p>
            <ul>
              <li>FOTO: foto yang mengandung unsur EDFAT (Entire, Detail, Framing, Angle, Time), masing-masing unsur sebanyak 1 foto sehingga total portofolio yang harus dikumpulkan berjumlah 5 foto.</li>
              <li>VIDEO: video berdurasi maksimal 2 menit dengan mengandung unsur visual teks, permainan warna, dan gaya pengambilan video (peserta dapat memilih 2 unsur)</li>
              <li>EDITOR: edited video dengan durasi maksimal 5 menit.</li>
            </ul>
          </div>
          <input type="text" name="portofolio" class="form-control" rows="3" value=<?php echo e(@old('portofolio')); ?>>
          <?php $__errorArgs = ['portofolio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-text">
              <?php echo e($message); ?>

            </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-danger" type="submit">Submit</button>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.user.master_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nabil\Commpress-2023\Compress-2023\resources\views/formRecruitment.blade.php ENDPATH**/ ?>